package com.example.odev6filmlistapp.model

data class Movie(
    val title: String,
    val imageUrl: String
)